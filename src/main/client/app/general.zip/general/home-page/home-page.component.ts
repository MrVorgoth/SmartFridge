import {Component} from "@angular/core";


@Component({
  selector: 'home-page',
  template: require('./home-page.component.html!text'),
  styles: [require('./home-page.component.css!text')]
} as Component)
export class HomePageComponent {

}

